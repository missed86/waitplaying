from api.models import Game, Cover, Platform, Screenshot, Scrapping, ReleaseDate
from django.db.models import Max
from django.http import HttpResponse