SECRET_KEY = 'iuhdsf87eyt346&%$GFGfdgfgdfokgpd'

ENGINE = 'django.db.backends.postgresql'
NAME = 'waitplaying'
USER = 'postgres'
PASSWORD = 'sevilla110789'
HOST = 'localhost'
PORT = '5432'